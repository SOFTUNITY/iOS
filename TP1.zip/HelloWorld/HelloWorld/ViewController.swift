//
//  ViewController.swift
//  HelloWorld
//
//  Created by Jean-Noël Aubry on 07/02/2016.
//  Copyright © 2016 SOFT UNITY. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

	@IBAction func showMessage() {
		let alertControl = UIAlertController(title:"Welcome to my first app", message: "Hello World", preferredStyle: UIAlertControllerStyle.Alert)
		
		alertControl.addAction(UIAlertAction(title:"OK",style: UIAlertActionStyle.Default,handler: nil))
		self.presentViewController(alertControl, animated: true, completion: nil)
	}
	
	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view, typically from a nib.
	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}


}

