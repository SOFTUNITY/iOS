//
//  ViewController.swift
//  Beep
//
//  Created by Jean-Noël Aubry on 18/04/15.
//  Copyright (c) 2015 Example. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    let player = AVPlayer(URL: NSBundle.mainBundle().URLForResource("trumpet", withExtension: "mp3")!)

    @IBAction func honk(sender: AnyObject) {
        player.play()
    }

}

